# __init__.py
from .monitor import main
